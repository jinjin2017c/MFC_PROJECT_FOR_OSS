# -*- coding: utf-8 -*-

#import oss2

#auth = oss2.Auth('LTAIomCMBttjFRJj', 'mrlRsN52kfdoqPJYCZxyaNzn1EsniF')
#service = oss2.Service(auth, 'oss-cn-beijing.aliyuncs.com')

#b.name for b in oss2.BucketIterator(service)
import winsound
winsound.Beep(600,1000)